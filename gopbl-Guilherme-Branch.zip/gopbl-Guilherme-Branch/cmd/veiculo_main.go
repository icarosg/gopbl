// Package main é o ponto de entrada para a simulação do veículo elétrico
package main

import (
	"fmt"
	"gopbl/cliente"
	"os"
	"os/signal"
	"syscall"
)

// main é a função principal que inicia a simulação do veículo
func main() {
	fmt.Println("Iniciando veículo cliente...")

	// Inicia o cliente do veículo em uma goroutine separada
	// para não bloquear o tratamento de sinais
	go cliente.IniciarVeiculo()

	// Configura um canal para receber sinais de interrupção (Ctrl+C)
	// e término do programa
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	// Aguarda até receber um sinal de interrupção
	<-sigChan

	fmt.Println("Encerrando veículo cliente...")
}
