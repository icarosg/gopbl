// Package main implementa o servidor de postos de recarga de veículos elétricos
package main

import (
	"encoding/json"
	"fmt"
	"gopbl/modelo"
	"log"
	"net/http"
	"sync"
)

// Mapa global que armazena todos os postos de recarga
// A chave é o ID do posto e o valor é um ponteiro para a estrutura do posto
var postos = make(map[string]*modelo.Posto)

// Mutex para garantir acesso seguro ao mapa de postos em ambiente concorrente
var postosMutex sync.Mutex

// LocalizacaoRequest representa o corpo da requisição recebida dos veículos
// contendo informações sobre sua localização e estado atual
type LocalizacaoRequest struct {
	VeiculoID string  `json:"veiculo_id"` // Identificador único do veículo
	Latitude  float64 `json:"latitude"`   // Latitude atual do veículo
	Longitude float64 `json:"longitude"`  // Longitude atual do veículo
	Bateria   float64 `json:"bateria"`    // Nível atual da bateria em porcentagem
}

// PostoResponse representa a resposta enviada aos veículos contendo
// informações sobre um posto de recarga
type PostoResponse struct {
	ID         string  `json:"id"`         // Identificador único do posto
	Latitude   float64 `json:"latitude"`   // Latitude do posto
	Longitude  float64 `json:"longitude"`  // Longitude do posto
	Disponivel bool    `json:"disponivel"` // Indica se o posto está disponível para recarga
}

// ReservaResponse representa a resposta enviada ao veículo após
// uma tentativa de reserva de vaga
type ReservaResponse struct {
	PostoID     string `json:"posto_id"`               // ID do posto onde foi feita a reserva
	VeiculoID   string `json:"veiculo_id"`             // ID do veículo que fez a reserva
	Reservado   bool   `json:"reservado"`              // Indica se a reserva foi bem sucedida
	PosicaoFila int    `json:"posicao_fila,omitempty"` // Posição na fila de espera (se houver)
}

// init inicializa o servidor criando os postos de recarga iniciais
func init() {
	// Cria três postos em diferentes cidades
	posto1 := modelo.NovoPosto("P001", -23.5505, -46.6333) // São Paulo
	posto2 := modelo.NovoPosto("P002", -22.9068, -43.1729) // Rio de Janeiro
	posto3 := modelo.NovoPosto("P003", -19.9227, -43.9452) // Belo Horizonte

	// Adiciona os postos ao mapa global
	postos["P001"] = &posto1
	postos["P002"] = &posto2
	postos["P003"] = &posto3

	fmt.Println("Postos de recarga inicializados com valores padrão.")
}

// listarPostosHandler processa requisições GET para /api/postos
// Retorna a lista de todos os postos de recarga e seus estados atuais
func listarPostosHandler(w http.ResponseWriter, r *http.Request) {
	postosMutex.Lock()
	defer postosMutex.Unlock()

	// Prepara a lista de respostas
	var postosResponse []PostoResponse
	for id, posto := range postos {
		postosResponse = append(postosResponse, PostoResponse{
			ID:         id,
			Latitude:   posto.Latitude,
			Longitude:  posto.Longitude,
			Disponivel: !modelo.GetBombaDisponivel(posto),
		})
	}

	//diz que vai enviar as resposta em formato json e codifica a resposta
	// Envia a resposta em formato JSON
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(postosResponse)
}

// reservarVagaHandler processa requisições POST para /api/reservar
// Tenta reservar uma vaga para um veículo em um posto específico
func reservarVagaHandler(w http.ResponseWriter, r *http.Request) {
	// Verifica se o método é POST
	if r.Method != http.MethodPost {
		http.Error(w, "Método não permitido", http.StatusMethodNotAllowed)
		return
	}

	// Decodifica o corpo da requisição
	var req LocalizacaoRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Obtém o ID do posto dos parâmetros da URL
	postoID := r.URL.Query().Get("posto_id")
	if postoID == "" {
		http.Error(w, "Posto ID é obrigatório", http.StatusBadRequest)
		return
	}

	// Tenta encontrar o posto solicitado
	postosMutex.Lock()
	posto, exists := postos[postoID]
	if !exists {
		postosMutex.Unlock()
		http.Error(w, "Posto não encontrado", http.StatusNotFound)
		return
	}

	// Cria uma estrutura de veículo com os dados recebidos
	veiculo := modelo.Veiculo{
		ID:        req.VeiculoID,
		Latitude:  req.Latitude,
		Longitude: req.Longitude,
		Bateria:   req.Bateria,
	}

	// Tenta reservar a vaga
	reservado := modelo.ReservarVaga(posto, &veiculo)
	var posicaoFila int
	if !reservado {
		posicaoFila = posto.QtdFila
	}
	postosMutex.Unlock()

	// Prepara e envia a resposta
	response := ReservaResponse{
		PostoID:     postoID,
		VeiculoID:   req.VeiculoID,
		Reservado:   reservado,
		PosicaoFila: posicaoFila,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)

	// Se a reserva foi bem sucedida, inicia o carregamento em uma goroutine separada
	if reservado {
		go func() {
			modelo.CarregarBateria(&veiculo)
		}()
	}
}

// liberarVagaHandler processa requisições POST para /api/liberar
// Libera uma vaga ocupada em um posto específico
func liberarVagaHandler(w http.ResponseWriter, r *http.Request) {
	// Verifica se o método é POST
	if r.Method != http.MethodPost {
		http.Error(w, "Método não permitido", http.StatusMethodNotAllowed)
		return
	}

	// Obtém o ID do posto dos parâmetros da URL
	postoID := r.URL.Query().Get("posto_id")
	if postoID == "" {
		http.Error(w, "Posto ID é obrigatório", http.StatusBadRequest)
		return
	}

	// Tenta encontrar o posto solicitado
	postosMutex.Lock()
	posto, exists := postos[postoID]
	if !exists {
		postosMutex.Unlock()
		http.Error(w, "Posto não encontrado", http.StatusNotFound)
		return
	}

	// Libera a vaga
	modelo.LiberarVaga(posto)
	postosMutex.Unlock()

	w.WriteHeader(http.StatusOK)
	fmt.Fprintf(w, "Vaga liberada com sucesso no posto %s", postoID)
}

// statusCarregamentoHandler processa requisições GET para /api/status
// Retorna o status atual de carregamento de um veículo
func statusCarregamentoHandler(w http.ResponseWriter, r *http.Request) {
	// Obtém o ID do veículo dos parâmetros da URL
	veiculoID := r.URL.Query().Get("veiculo_id")
	if veiculoID == "" {
		http.Error(w, "Veículo ID é obrigatório", http.StatusBadRequest)
		return
	}

	// Prepara e envia a resposta com o status do veículo
	status := struct {
		VeiculoID    string  `json:"veiculo_id"`
		Carregando   bool    `json:"carregando"`
		NivelBateria float64 `json:"nivel_bateria"`
	}{
		VeiculoID:    veiculoID,
		Carregando:   false,
		NivelBateria: 100.0,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(status)
}

// main é o ponto de entrada do servidor
func main() {
	// Configura os handlers para cada endpoint da API
	http.HandleFunc("/api/postos", listarPostosHandler)
	http.HandleFunc("/api/reservar", reservarVagaHandler)
	http.HandleFunc("/api/liberar", liberarVagaHandler)
	http.HandleFunc("/api/status", statusCarregamentoHandler)

	// Inicia o servidor na porta 8080
	port := ":8080"
	fmt.Printf("Servidor de postos iniciado na porta %s\n", port)
	log.Fatal(http.ListenAndServe(port, nil))
}
