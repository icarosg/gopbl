// Package main implementa o servidor de postos de recarga de veículos elétricos
package main

import (
	"encoding/json"
	"fmt"
	"gopbl/modelo"
	"log"

	//"log"
	"net/http"
	"sync"
)

// A chave é o ID do posto e o valor é um ponteiro para a estrutura do posto
var postos1 = make(map[string]*modelo.Posto)

// Mutex para garantir acesso seguro ao mapa de postos em ambiente concorrente
var postosMutex1 sync.Mutex

type PostoResposta struct {
	ID         string  `json:"id"`        // Identificador único do posto
	Latitude   float64 `json:"latitude"`  // Latitude do posto
	Longitude  float64 `json:"longitude"` // Longitude do posto
	QtdFila    int     `json:"quantidade de carros na fila"`
	Disponivel bool    `json:"tem bomba disponivel"` // Indica se o posto está disponível para recarga
}

type VeiculoRequest struct {
	VeiculoID string  `json:"veiculo_id"` // Identificador único do veículo
	Latitude  float64 `json:"latitude"`   // Latitude atual do veículo
	Longitude float64 `json:"longitude"`  // Longitude atual do veículo
	Bateria   float64 `json:"bateria"`    // Nível atual da bateria em porcentagem
}

type ReservaResponse1 struct {
	PostoID     string `json:"posto_id"`     // ID do posto onde foi feita a reserva
	VeiculoID   string `json:"veiculo_id"`   // ID do veículo que fez a reserva
	Reservado   bool   `json:"reservado"`    // Indica se a reserva foi bem sucedida
	PosicaoFila int    `json:"posicao_fila"` // Posição na fila de espera (se houver)
}

// init inicializa o servidor criando os postos de recarga iniciais
func init() {
	// Cria três postos em diferentes cidades
	posto1 := modelo.NovoPosto("P001", -23.5505, -46.6333) // São Paulo
	posto2 := modelo.NovoPosto("P002", -22.9068, -43.1729) // Rio de Janeiro
	posto3 := modelo.NovoPosto("P003", -19.9227, -43.9452) // Belo Horizonte

	// Adiciona os postos ao mapa global
	postos1["P001"] = &posto1
	postos1["P002"] = &posto2
	postos1["P003"] = &posto3

	fmt.Println("Postos de recarga inicializados com valores padrão.")
}

func listarPostosHandler1(w http.ResponseWriter, r *http.Request) {
	postosMutex1.Lock()
	defer postosMutex1.Unlock()

	// Prepara a lista de respostas
	var postosRespostas []PostoResposta
	for id, posto := range postos {
		postosRespostas = append(postosRespostas, PostoResposta{
			ID:         id,
			Latitude:   posto.Latitude,
			Longitude:  posto.Longitude,
			QtdFila:    posto.QtdFila,
			Disponivel: !modelo.GetBombaDisponivel(posto),
		})
	}

	//diz que vai enviar as resposta em formato json e codifica a resposta
	// Envia a resposta em formato JSON
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(postosRespostas)
}

func reservarVagaHandler1(w http.ResponseWriter, r *http.Request) {

	var req VeiculoRequest

	//decodifica o json
	json.NewDecoder(r.Body).Decode(&req)

	//pega o id do posto que deseja fazer a reserva
	postoID := r.URL.Query().Get("posto_id")
	posto := postos1[postoID]

	postosMutex1.Lock()

	//cria um veiculo com os mesmos parametros do veiculo que vai reservar a vaga
	veiculo := modelo.Veiculo{
		ID:        req.VeiculoID,
		Latitude:  req.Latitude,
		Longitude: req.Longitude,
		Bateria:   req.Bateria,
	}

	modelo.ReservarVaga(posto, &veiculo)
	posicaoFila := posto.QtdFila

	postosMutex1.Unlock()

	response := ReservaResponse1{
		PostoID:     posto.ID,
		VeiculoID:   veiculo.ID,
		Reservado:   true,
		PosicaoFila: posicaoFila,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)

	go func() {
		modelo.CarregarBateria(&veiculo)
	}()
}

func liberarVagaHandler1(w http.ResponseWriter, r *http.Request) {
	postoID := r.URL.Query().Get("posto_id")
	postosMutex1.Lock()
	posto := postos1[postoID]
	modelo.LiberarVaga(posto)
	postosMutex1.Unlock()
}

func main() {
	// Configura os handlers para cada endpoint da API
	http.HandleFunc("/api/postos", listarPostosHandler)
	http.HandleFunc("/api/reservar", reservarVagaHandler)
	http.HandleFunc("/api/liberar", liberarVagaHandler)
	http.HandleFunc("/api/status", statusCarregamentoHandler)

	// Inicia o servidor na porta 8080
	port := ":8080"
	fmt.Printf("Servidor de postos iniciado na porta %s\n", port)
	log.Fatal(http.ListenAndServe(port, nil))
}
