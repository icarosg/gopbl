# Sistema de Veículos Elétricos e Postos de Recarga

Este projeto simula um sistema de veículos elétricos interagindo com postos de recarga através de uma arquitetura de microserviços usando Docker containers.

## Arquitetura

O sistema é composto por:

1. **Servidor de Postos**: Uma API que gerencia os postos de recarga e suas disponibilidades
2. **Clientes Veículos**: Múltiplos containers representando veículos elétricos que se movem e precisam recarregar suas baterias

Os containers se comunicam através da rede Docker definida no `docker-compose.yml`.

## Estrutura do Projeto

```
.
├── modelo/                  # Pacote com as definições dos modelos
│   ├── veiculo.go           # Modelo do veículo
│   └── posto.go             # Modelo do posto de recarga
├── cliente/                 # Pacote cliente para os veículos
│   └── veiculo_cliente.go   # Implementação do cliente veículo
├── servidor/                # Servidor para os postos de recarga
│   └── posto_servidor.go    # Implementação do servidor de postos
├── cmd/                     # Comandos executáveis
│   └── veiculo_main.go      # Ponto de entrada para os clientes veículos
├── Dockerfile.posto         # Dockerfile para o servidor de postos
├── Dockerfile.veiculo       # Dockerfile para os clientes veículos
├── docker-compose.yml       # Configuração do Docker Compose
└── README.md                # Este arquivo
```

## Como Executar

1. Certifique-se de ter o Docker e o Docker Compose instalados.

2. Construa e inicie os containers:

```bash
docker-compose up -d
```

3. Observe os logs dos containers:

```bash
# Para ver todos os logs
docker-compose logs -f

# Para ver logs específicos
docker logs -f posto_server      # Servidor de postos
docker logs -f veiculo_v001      # Veículo 1
docker logs -f veiculo_v002      # Veículo 2
docker logs -f veiculo_v003      # Veículo 3
```

4. Pare os containers:

```bash
docker-compose down
```

## Funcionalidades

- Veículos se movimentam automaticamente
- Quando a bateria fica abaixo de 30%, o veículo procura um posto para recarregar
- Postos gerenciam filas e vagas de recarga
- Os veículos se comunicam com os postos através de uma API REST
- Cada veículo exibe seu estado atual (localização, bateria) nos logs

## Variáveis de Ambiente

Os clientes veículos podem ser configurados com:

- `POSTO_SERVER_URL`: URL do servidor de postos (padrão: "http://posto_server:8080")
- `VEICULO_ID`: ID único do veículo (padrão: gerado aleatoriamente) 