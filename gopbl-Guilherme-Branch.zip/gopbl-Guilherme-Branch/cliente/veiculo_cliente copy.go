// Package cliente implementa a lógica do cliente do veículo elétrico
package cliente

import (
	"bytes"
	"encoding/json"
	"fmt"
	"gopbl/modelo"
	"math/rand"
	"net/http"
	"os"
	"time"
)

// LocalizacaoRequest representa o corpo da requisição para enviar a localização do veículo
// ao servidor de postos de recarga
type LocalizacaoRequest struct {
	VeiculoID string  `json:"veiculo_id"` // Identificador único do veículo
	Latitude  float64 `json:"latitude"`   // Latitude atual do veículo
	Longitude float64 `json:"longitude"`  // Longitude atual do veículo
	Bateria   float64 `json:"bateria"`    // Nível atual da bateria em porcentagem
}

// PostoResponse representa a resposta do servidor contendo informações sobre um posto de recarga
type PostoResponse struct {
	ID         string  `json:"id"`         // Identificador único do posto
	Latitude   float64 `json:"latitude"`   // Latitude do posto
	Longitude  float64 `json:"longitude"`  // Longitude do posto
	Disponivel bool    `json:"disponivel"` // Indica se o posto está disponível para recarga
}

// ReservaResponse representa a resposta do servidor após uma tentativa de reserva de vaga
type ReservaResponse struct {
	PostoID     string `json:"posto_id"`               // ID do posto onde foi feita a reserva
	VeiculoID   string `json:"veiculo_id"`             // ID do veículo que fez a reserva
	Reservado   bool   `json:"reservado"`              // Indica se a reserva foi bem sucedida
	PosicaoFila int    `json:"posicao_fila,omitempty"` // Posição na fila de espera (se houver)
}

// EstadoVeiculo mantém o estado atual do veículo e suas estatísticas
type EstadoVeiculo struct {
	Veiculo       modelo.Veiculo // Informações básicas do veículo
	UltimaRecarga time.Time      // Momento da última recarga completa
	KmPercorridos float64        // Total de quilômetros percorridos
}

// Variáveis globais para configuração e estado do cliente
var (
	postoServerURL = getEnv("POSTO_SERVER_URL", "http://localhost:8080")        // URL do servidor de postos
	veiculoID      = getEnv("VEICULO_ID", fmt.Sprintf("V%03d", rand.Intn(999))) // ID único do veículo
	estadoVeiculo  EstadoVeiculo                                                // Estado atual do veículo
)

// getEnv retorna o valor de uma variável de ambiente ou um valor padrão se não definida
func getEnv(key, defaultValue string) string {
	value := os.Getenv(key)
	if value == "" {
		return defaultValue
	}
	return value
}

// inicializarVeiculo configura o estado inicial do veículo com posição aleatória em São Paulo
func inicializarVeiculo() {
	estadoVeiculo.Veiculo = modelo.NovoVeiculo(
		veiculoID,
		-23.5505+(rand.Float64()-0.5)*10, // Latitude inicial próxima a São Paulo
		-46.6333+(rand.Float64()-0.5)*10, // Longitude inicial próxima a São Paulo
	)
	estadoVeiculo.UltimaRecarga = time.Now()
	estadoVeiculo.KmPercorridos = 0.0

	fmt.Printf("Veículo %s inicializado com bateria completa\n", veiculoID)
}

// buscarPostos faz uma requisição GET ao servidor para obter a lista de postos disponíveis
func buscarPostos() ([]PostoResponse, error) {
	resp, err := http.Get(postoServerURL + "/api/postos")
	if err != nil {
		return nil, fmt.Errorf("erro ao buscar postos: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("erro ao buscar postos: %s", resp.Status)
	}

	var postos []PostoResponse
	if err := json.NewDecoder(resp.Body).Decode(&postos); err != nil {
		return nil, fmt.Errorf("erro ao decodificar resposta: %v", err)
	}

	return postos, nil
}

// reservarVaga tenta reservar uma vaga em um posto específico
func reservarVaga(postoID string) (*ReservaResponse, error) {
	// Prepara os dados da localização atual do veículo
	localizacao := LocalizacaoRequest{
		VeiculoID: estadoVeiculo.Veiculo.ID,
		Latitude:  estadoVeiculo.Veiculo.Latitude,
		Longitude: estadoVeiculo.Veiculo.Longitude,
		Bateria:   estadoVeiculo.Veiculo.Bateria,
	}

	// Serializa os dados para JSON
	reqBody, err := json.Marshal(localizacao)
	if err != nil {
		return nil, fmt.Errorf("erro ao criar requisição: %v", err)
	}

	// Faz a requisição POST para reservar a vaga
	resp, err := http.Post(
		fmt.Sprintf("%s/api/reservar?posto_id=%s", postoServerURL, postoID),
		"application/json",
		bytes.NewBuffer(reqBody),
	)
	if err != nil {
		return nil, fmt.Errorf("erro ao reservar vaga: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("erro ao reservar vaga: %s", resp.Status)
	}

	// Decodifica a resposta
	var reserva ReservaResponse
	if err := json.NewDecoder(resp.Body).Decode(&reserva); err != nil {
		return nil, fmt.Errorf("erro ao decodificar resposta: %v", err)
	}

	return &reserva, nil
}

// liberarVaga libera a vaga ocupada pelo veículo em um posto específico
func liberarVaga(postoID string) error {
	resp, err := http.Post(
		fmt.Sprintf("%s/api/liberar?posto_id=%s", postoServerURL, postoID),
		"application/json",
		nil,
	)
	if err != nil {
		return fmt.Errorf("erro ao liberar vaga: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("erro ao liberar vaga: %s", resp.Status)
	}

	return nil
}

// moverVeiculo atualiza a posição do veículo e diminui o nível da bateria
func moverVeiculo() {
	modelo.AtualizarLocalizacao(&estadoVeiculo.Veiculo)
	modelo.DiminuirNivelBateria(&estadoVeiculo.Veiculo)

	estadoVeiculo.KmPercorridos += 0.5

	fmt.Printf("Veículo em movimento - Km total: %.2f\n", estadoVeiculo.KmPercorridos)
}

// encontrarPostoProximo identifica o posto de recarga disponível mais próximo
func encontrarPostoProximo(postos []PostoResponse) *PostoResponse {
	if len(postos) == 0 {
		return nil
	}

	var postoMaisProximo *PostoResponse
	menorDistancia := 999999.0

	// Calcula a distância euclidiana para cada posto
	for i, posto := range postos {
		distancia := (posto.Latitude-estadoVeiculo.Veiculo.Latitude)*(posto.Latitude-estadoVeiculo.Veiculo.Latitude) +
			(posto.Longitude-estadoVeiculo.Veiculo.Longitude)*(posto.Longitude-estadoVeiculo.Veiculo.Longitude)

		if distancia < menorDistancia && posto.Disponivel {
			menorDistancia = distancia
			postoMaisProximo = &postos[i]
		}
	}

	return postoMaisProximo
}

// irParaPosto move o veículo para a localização do posto escolhido
func irParaPosto(posto *PostoResponse) {
	fmt.Printf("Veículo %s está se deslocando para o posto %s\n", estadoVeiculo.Veiculo.ID, posto.ID)

	// Atualiza a posição do veículo para a localização do posto
	estadoVeiculo.Veiculo.Latitude = posto.Latitude
	estadoVeiculo.Veiculo.Longitude = posto.Longitude

	fmt.Printf("Veículo %s chegou ao posto %s\n", estadoVeiculo.Veiculo.ID, posto.ID)
}

// IniciarVeiculo é a função principal que inicia a simulação do veículo
func IniciarVeiculo() {
	// Inicializa o gerador de números aleatórios
	rand.Seed(time.Now().UnixNano())

	// Configura o estado inicial do veículo
	inicializarVeiculo()

	fmt.Printf("Veículo %s iniciado na posição (%.6f, %.6f) com bateria %.2f%%\n",
		estadoVeiculo.Veiculo.ID, estadoVeiculo.Veiculo.Latitude, estadoVeiculo.Veiculo.Longitude, estadoVeiculo.Veiculo.Bateria)

	cicloTempo := 5 * time.Second

	var postoAtual *PostoResponse
	carregando := false

	// Loop principal da simulação
	for {
		if !carregando {
			// Modo de movimento normal
			moverVeiculo()
			fmt.Printf("Veículo %s em movimento - Posição: (%.6f, %.6f) - Bateria: %.2f%%\n",
				estadoVeiculo.Veiculo.ID, estadoVeiculo.Veiculo.Latitude, estadoVeiculo.Veiculo.Longitude, estadoVeiculo.Veiculo.Bateria)

			// Verifica se precisa recarregar (bateria abaixo de 30%)
			if estadoVeiculo.Veiculo.Bateria < 30.0 {
				fmt.Printf("Bateria baixa (%.2f%%). Procurando posto de recarga...\n", estadoVeiculo.Veiculo.Bateria)

				// Busca postos disponíveis
				postos, err := buscarPostos()
				if err != nil {
					fmt.Printf("Erro ao buscar postos: %v\n", err)
				} else if len(postos) > 0 {
					// Encontra o posto mais próximo
					postoProximo := encontrarPostoProximo(postos)
					if postoProximo != nil {
						postoAtual = postoProximo
						irParaPosto(postoProximo)

						// Tenta reservar uma vaga
						reserva, err := reservarVaga(postoProximo.ID)
						if err != nil {
							fmt.Printf("Erro ao reservar vaga: %v\n", err)
						} else if reserva.Reservado {
							fmt.Printf("Vaga reservada no posto %s. Iniciando carregamento.\n", postoProximo.ID)
							carregando = true
							estadoVeiculo.Veiculo.IsCarregando = true
						} else {
							fmt.Printf("Posto ocupado. Em fila de espera, posição: %d\n", reserva.PosicaoFila)
						}
					}
				}
			}
		} else {
			// Modo de carregamento
			// Simula uma chance aleatória de terminar o carregamento
			if rand.Intn(10) < 3 {
				fmt.Printf("Carregamento concluído. Bateria: 100%%\n")
				carregando = false
				estadoVeiculo.Veiculo.IsCarregando = false
				estadoVeiculo.Veiculo.Bateria = 100.0
				estadoVeiculo.UltimaRecarga = time.Now()

				// Libera a vaga no posto
				if postoAtual != nil {
					err := liberarVaga(postoAtual.ID)
					if err != nil {
						fmt.Printf("Erro ao liberar vaga: %v\n", err)
					} else {
						fmt.Printf("Vaga liberada no posto %s\n", postoAtual.ID)
						postoAtual = nil
					}
				}
			} else {
				fmt.Printf("Veículo %s carregando no posto %s - Bateria: %.2f%%\n",
					estadoVeiculo.Veiculo.ID, postoAtual.ID, estadoVeiculo.Veiculo.Bateria)
			}
		}

		// Aguarda o próximo ciclo
		time.Sleep(cicloTempo)
	}
}
