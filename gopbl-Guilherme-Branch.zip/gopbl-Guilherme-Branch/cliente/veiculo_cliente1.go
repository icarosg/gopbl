// Package cliente implementa a lógica do cliente do veículo elétrico
package cliente
