package modelo

import (
	"fmt"
	"sync"
	"time"
)

type Posto struct {
	ID           string
	Latitude     float64
	Longitude    float64
	mu           sync.Mutex
	Fila         []*Veiculo
	QtdFila      int
	BombaOcupada bool
}

func NovoPosto(id string, lat float64, long float64) Posto {
	fmt.Printf("Posto %s criado na localização (%.6f, %.6f)",
		id, lat, long)

	return Posto{
		ID:           id,
		Latitude:     lat,
		Longitude:    long,
		Fila:         make([]*Veiculo, 0),
		QtdFila:      0,
		BombaOcupada: false,
	}
}

func ReservarVaga(p *Posto, v *Veiculo) bool {
	p.mu.Lock()
	defer p.mu.Unlock()

	if !p.BombaOcupada && p.Latitude == v.Latitude && p.Longitude == v.Longitude {
		p.BombaOcupada = true
		fmt.Printf("Posto %s: Vaga reservada para veículo %s.", p.ID, v.ID)
		return true
	}

	p.Fila = append(p.Fila, v)
	fmt.Printf("Posto %s: Veículo %s adicionado à fila de espera. Posição: %d", p.ID, v.ID, p.QtdFila)
	return false
}

func LiberarVaga(p *Posto) {
	p.mu.Lock()
	defer p.mu.Unlock()

	p.BombaOcupada = false
	fmt.Printf("Posto %s com a bomba liberada.\n", p.ID)

	if len(p.Fila) > 0 {
		for i := range p.Fila {
			if p.Fila[i].Latitude == p.Latitude && p.Fila[i].Longitude == p.Longitude {
				carregarBateriaVeiculo := p.Fila[i]

				p.Fila = append(p.Fila[:i], p.Fila[i+1:]...)

				CarregarBateria(carregarBateriaVeiculo)
				fmt.Printf("Posto %s: Veículo %s removido da fila e iniciando carregamento\n", p.ID, carregarBateriaVeiculo.ID)

				p.BombaOcupada = true
				break
			}
		}
	}
}

func GetBombaDisponivel(p *Posto) bool {
	p.mu.Lock()
	defer p.mu.Unlock()

	return p.BombaOcupada
}

func GetLocalizacaoPosto(p *Posto) (float64, float64) {
	p.mu.Lock()
	defer p.mu.Unlock()

	return p.Latitude, p.Longitude
}

func PararCarregamentoBateria(v *Veiculo) {
	v.mu.Lock()
	defer v.mu.Unlock()

	v.IsCarregando = false
	v.Bateria = 100.0
	fmt.Printf("[%s] Carregamento concluído em: %s | Nível de bateria: %.2f%%\n", v.ID, time.Now().Format("02/01/2006 15:04:05"), v.Bateria)
}

func CarregarBateria(v *Veiculo) {
	v.mu.Lock()
	v.IsCarregando = true
	tempoInicio := time.Now()
	fmt.Printf("[%s] Carregamento iniciado em: %s | Nível de bateria inicial: %.2f%%\n", v.ID, tempoInicio.Format("02/01/2006 15:04:05"), v.Bateria)
	v.mu.Unlock()

	go func() {
		time.Sleep(1 * time.Minute)

		v.mu.Lock()
		PararCarregamentoBateria(v)
		v.mu.Unlock()
	}()
}
