package modelo

import (
	"math/rand"
	"sync"
)

type Veiculo struct {
	ID           string
	Latitude     float64
	Longitude    float64
	Bateria      float64
	mu           sync.Mutex
	IsCarregando bool
}

func NovoVeiculo(id string, inicialLat float64, inicialLong float64) Veiculo {
	return Veiculo{
		ID:           id,
		Latitude:     inicialLat,
		Longitude:    inicialLong,
		Bateria:      100.0,
		IsCarregando: false,
	}
}

func AtualizarLocalizacao(v *Veiculo) {
	v.mu.Lock()
	defer v.mu.Unlock()

	v.Latitude += (rand.Float64() - 0.5) * 0.001
	v.Longitude += (rand.Float64() - 0.5) * 0.001
}

func DiminuirNivelBateria(v *Veiculo) {
	v.mu.Lock()
	defer v.mu.Unlock()

	if !v.IsCarregando {
		v.Bateria -= rand.Float64()*30.4 + 15.1
		if v.Bateria < 0 {
			v.Bateria = 0
		}
	}
}

func GetNivelBateria(v *Veiculo) float64 {
	v.mu.Lock()
	defer v.mu.Unlock()

	return v.Bateria
}

func GetLocalizacaoVeiculo(v *Veiculo) (float64, float64) {
	v.mu.Lock()
	defer v.mu.Unlock()

	return v.Latitude, v.Longitude
}
